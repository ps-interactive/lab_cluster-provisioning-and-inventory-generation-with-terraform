terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
    null = {
      source  = "hashicorp/null"
      version = "~> 3.0"
    }
  }
}

# -----------------------------------------------
# Provider aliases — one per remote Docker node
# Each tunnels Docker API securely over SSH
# -----------------------------------------------
# Local Docker host
provider "docker" {
  alias = "node1"
  host  = "unix:///var/run/docker.sock"
}

# Remote Docker host
provider "docker" {
  alias = "node2"
  host  = "ssh://${var.ssh_user}@${var.node_ips[0]}:22"

  ssh_opts = [
    "-i", var.ssh_private_key_path,
    "-o", "StrictHostKeyChecking=no",
    "-o", "UserKnownHostsFile=/dev/null"
  ]
}

# -----------------------------------------------
# Pull Ubuntu image on Node 1
# -----------------------------------------------
resource "docker_image" "ubuntu_node1" {
  provider = docker.node1
  name     = var.container_image

  keep_locally = true
}

# -----------------------------------------------
# Pull Ubuntu image on Node 2
# -----------------------------------------------
resource "docker_image" "ubuntu_node2" {
  provider = docker.node2
  name     = var.container_image

  keep_locally = true
}

# -----------------------------------------------
# Dedicated bridge network on Node 1
# Enables isolated, secure inter-container comms
# -----------------------------------------------
resource "docker_network" "cluster_net_node1" {
  provider = docker.node1
  name     = var.docker_network_name

  driver = "bridge"

  ipam_config {
    subnet  = "172.20.0.0/24"
    gateway = "172.20.0.1"
  }

  options = {
    "com.docker.network.bridge.enable_icc"           = "true"   # inter-container comms
    "com.docker.network.bridge.enable_ip_masquerade" = "true"   # NAT for external traffic
  }
}

# -----------------------------------------------
# Dedicated bridge network on Node 2
# -----------------------------------------------
resource "docker_network" "cluster_net_node2" {
  provider = docker.node2
  name     = var.docker_network_name

  driver = "bridge"

  ipam_config {
    subnet  = "172.21.0.0/24"
    gateway = "172.21.0.1"
  }

  options = {
    "com.docker.network.bridge.enable_icc"           = "true"
    "com.docker.network.bridge.enable_ip_masquerade" = "true"
  }
}

# -----------------------------------------------
# Ubuntu container on Node 1
# -----------------------------------------------
resource "docker_container" "ubuntu_node1" {
  provider = docker.node1
  name     = "ubuntu-cluster-node1"
  image    = docker_image.ubuntu_node1.image_id

  # Minimal compute resources for the workload
  memory      = 256   # MB
  memory_swap = 512   # MB (memory + swap)
  cpu_shares  = 512   # Relative weight (1024 = full core)

  # Keep container alive
  command = ["sleep", "infinity"]

  restart = "unless-stopped"

  # Attach to the cluster network
  networks_advanced {
    name         = docker_network.cluster_net_node1.name
    ipv4_address = "172.20.0.10"
  }

  # Expose SSH port from container to host
  ports {
    internal = 22
    external = 2222
    protocol = "tcp"
  }

  # Mount SSH authorized_keys for container SSH access
  volumes {
    host_path      = "/home/${var.ssh_user}/.ssh/authorized_keys"
    container_path = "/root/.ssh/authorized_keys"
    read_only      = true
  }

  # Environment variables
  env = [
    "NODE_ROLE=primary",
    "CLUSTER_PEER=${var.node_ips[0]}"
  ]

  # Labels for management/identification
  labels {
     label = "cluster.node"
    value = "1"
  }
  labels {
    label = "cluster.role"
    value = "primary"
  }
}

# -----------------------------------------------
# Ubuntu container on Node 2
# -----------------------------------------------
resource "docker_container" "ubuntu_node2" {
  provider = docker.node2
  name     = "ubuntu-cluster-node2"
  image    = docker_image.ubuntu_node2.image_id

  memory      = 256
  memory_swap = 512
  cpu_shares  = 512

  command = ["sleep", "infinity"]
  restart = "unless-stopped"

  networks_advanced {
    name         = docker_network.cluster_net_node2.name
    ipv4_address = "172.21.0.10"
  }

  ports {
    internal = 22
    external = 2222
    protocol = "tcp"
  }

  volumes {
    host_path      = "/home/${var.ssh_user}/.ssh/authorized_keys"
    container_path = "/root/.ssh/authorized_keys"
    read_only      = true
  }

  env = [
    "NODE_ROLE=secondary",
    "CLUSTER_PEER='127.0.0.1'"
  ]

  labels {
    label = "cluster.node"
    value = "2"
  }
  labels {
    label = "cluster.role"
    value = "secondary"
  }
}

# -----------------------------------------------
# Bootstrap inside Node 1 container
# Installs OpenSSH server post-launch
# -----------------------------------------------
resource "null_resource" "bootstrap_ssh_node1" {
  depends_on = [docker_container.ubuntu_node1]

  provisioner "local-exec" {
    command = <<EOT
docker exec ubuntu-cluster-node1 apt-get update -qq
docker exec ubuntu-cluster-node1 apt-get install -y openssh-server -qq
docker exec ubuntu-cluster-node1 mkdir -p /root/.ssh
docker exec ubuntu-cluster-node1 mkdir -p /var/run/sshd
docker exec ubuntu-cluster-node1 sh -c "cat /host_key >> /root/.ssh/authorized_keys"
docker exec ubuntu-cluster-node1 chmod 700 /root/.ssh
docker exec ubuntu-cluster-node1 chmod 600 /root/.ssh/authorized_keys
docker exec ubuntu-cluster-node1 sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
docker exec ubuntu-cluster-node1 service ssh start
EOT
  }
}

# -----------------------------------------------
# Bootstrap SSH inside Node 2 container
# -----------------------------------------------
resource "null_resource" "bootstrap_ssh_node2" {
  depends_on = [docker_container.ubuntu_node2]

  connection {
    type        = "ssh"
    host        = var.node_ips[0]
    user        = var.ssh_user
    private_key = file(var.ssh_private_key_path)
    port        = 22
  }

  provisioner "remote-exec" {
    inline = [
      "docker exec ubuntu-cluster-node2 apt-get update -qq",
      "docker exec ubuntu-cluster-node2 apt-get install -y openssh-server -qq",
      "docker exec ubuntu-cluster-node2 mkdir -p /root/.ssh",
      "docker exec ubuntu-cluster-node2 mkdir -p /var/run/sshd",
      "docker exec ubuntu-cluster-node2 sh -c 'cat /host_key >> /root/.ssh/authorized_keys'",
      "docker exec ubuntu-cluster-node2 chmod 700 /root/.ssh",
      "docker exec ubuntu-cluster-node2 service ssh start"
    ]
  }
}
